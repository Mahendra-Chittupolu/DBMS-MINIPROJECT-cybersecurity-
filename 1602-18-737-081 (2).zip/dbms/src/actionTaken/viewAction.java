package actionTaken;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class viewAction {
	Connection connection;
	Statement statement;
	ResultSet rs;
	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Mahendra","sqlmahi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }


	public void vwacn() {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		JFrame f = new JFrame();
		JPanel pnl = new JPanel();
		JLabel lbleid = new JLabel("EID");
		JLabel lblresl = new JLabel("DATE RESOLVED");
		JLabel lblpid = new JLabel("PID");
		JTextField jtfeid = new JTextField(15);
		JTextField jtfresl = new JTextField(15);
		JTextField jtfpid = new JTextField(15);
		JButton btn = new JButton("MODIFY");
		JTextArea jtadesc = new JTextArea(15,55);
		JPanel pnl1 = new JPanel();
		List lipid = new List(10);
		jtadesc.setEditable(false);
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM ACTION_TAKEN");
		  while (rs.next()) 
		  {
			lipid.add(rs.getString("PID"));
		  }
		} 
		catch (SQLException e) 
		{ 
			jtadesc.append("\nSQLException: " + e.getMessage() + "\n");
			jtadesc.append("SQLState:     " + e.getSQLState() + "\n");
			jtadesc.append("VendorError:  " + e.getErrorCode() + "\n");
		}
lipid.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				try {
					rs = statement.executeQuery("select *from action_taken where pid = "+lipid.getSelectedItem());
					rs.next();
					jtfpid.setText(rs.getString("PID"));
					jtfeid.setText(rs.getString("EID"));
					
					jtfresl.setText(rs.getString("DATE_RESOLVED"));
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					jtadesc.append("\nSQLException: " + e1.getMessage() + "\n");
					jtadesc.append("SQLState:     " + e1.getSQLState() + "\n");
					jtadesc.append("VendorError:  " + e1.getErrorCode() + "\n");
					
				}
				
			}
		});
btn.addActionListener(new ActionListener() {
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		try {
			Statement statement = connection.createStatement();
			int i = statement.executeUpdate("update action_taken set pid ='"+jtfpid.getText()+"',eid ='"+jtfeid.getText()+"',date_resolved ="
					+ "'"+jtfresl.getText()+"' where pid = '"+lipid.getSelectedItem()+"'");
			jtadesc.setText(null);
			jtadesc.append("Updated"+i+"rows sucessfully");
			lipid.removeAll();
			jtfpid.setText(null);
			jtfeid.setText(null);
			jtfresl.setText(null);
			
			try 
			{
			  rs = statement.executeQuery("SELECT * FROM ACTION_TAKEN");
			  while (rs.next()) 
			  {
				lipid.add(rs.getString("PID"));
			  }
			} 
			catch (SQLException e1) 
			{ 
				jtadesc.append("\nSQLException: " + e1.getMessage() + "\n");
				jtadesc.append("SQLState:     " + e1.getSQLState() + "\n");
				jtadesc.append("VendorError:  " + e1.getErrorCode() + "\n");
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			jtadesc.append("\nSQLException: " + e1.getMessage() + "\n");
			jtadesc.append("SQLState:     " + e1.getSQLState() + "\n");
			jtadesc.append("VendorError:  " + e1.getErrorCode() + "\n");
		}
		
	}
});



		pnl1.add(lipid);
		
		pnl.add(lbleid);
		pnl.add(jtfeid);
		pnl.add(lblresl);
		pnl.add(jtfresl);
		pnl.add(lblpid);
		pnl.add(jtfpid);
		pnl.add(btn);
		pnl.add(jtadesc);
		pnl1.setLayout(new FlowLayout());
		pnl.setLayout(new FlowLayout());
		f.add(pnl1);
		f.add(pnl);
		f.setLayout(new FlowLayout());
		f.getContentPane().setBackground(Color.DARK_GRAY);
		f.setSize(1500,600);
		f.setVisible(true);

	}

}
