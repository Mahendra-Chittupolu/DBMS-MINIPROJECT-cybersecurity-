package actionTaken;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class insertAction {
	Connection connection;
	Statement statement;
	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Mahendra","sqlmahi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	

	public void insactn() {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		JFrame f = new JFrame();
		JPanel pnl = new JPanel();
		JLabel lbleid = new JLabel("EID");
		JLabel lblresl = new JLabel("DATE RESOLVED");
		JLabel lblpid = new JLabel("PID");
		JTextField jtfeid = new JTextField(15);
		JTextField jtfresl = new JTextField(15);
		JTextField jtfpid = new JTextField(15);
		JButton btn = new JButton("SUBMIT");
		JTextArea jta = new JTextArea(15,55);
		jta.setEditable(false);
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					Statement statement = connection.createStatement();
					String query = "INSERT INTO ACTION_TAKEN VALUES('"+jtfpid.getText()+"','"+jtfeid.getText()+"','"+jtfresl.getText()+"')";
					int i = statement.executeUpdate(query);
					jta.append("\n INSERTED"+i+"Queries sucessfully");
					jtfpid.setText(null);
					jtfeid.setText(null);
					jtfresl.setText(null);
				
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					jta.append("\nSQLException: " + e1.getMessage() + "\n");
		     		jta.append("SQLState:     " + e1.getSQLState() + "\n");
		     		jta.append("VendorError:  " + e1.getErrorCode() + "\n");
		     		jtfpid.setText(null);
					jtfeid.setText(null);
					jtfresl.setText(null);
					
				}
				
			}
		});
		pnl.add(lbleid);
		pnl.add(jtfeid);
		pnl.add(lblresl);
		pnl.add(jtfresl);
		pnl.add(lblpid);
		pnl.add(jtfpid);
		pnl.add(btn);
		pnl.add(jta);
		pnl.setLayout(new FlowLayout());
		f.getContentPane().setBackground(Color.DARK_GRAY);
		f.add(pnl);
		f.setLayout(new FlowLayout());
		f.setSize(1500,600);
		f.setVisible(true);
		
	}

}
