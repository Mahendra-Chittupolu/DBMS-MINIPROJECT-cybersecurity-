package launch;

import view.cyberGUI;

public class cyberLaunch {
		public static void main(String args[])
		{
			new cyberGUI();
		}

}
