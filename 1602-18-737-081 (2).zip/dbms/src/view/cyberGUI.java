package view;

import java.awt.CardLayout;
import java.awt.Color;

import complaintsReceived.*;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagLayout;
import complaintsReceived.*;

import users.*;

import java.awt.GridLayout;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.Border;

import actionTaken.delAction;
import actionTaken.insertAction;
import actionTaken.viewAction;
import complaintsReceived.insertComplaints;
import criminalRecords.delCriminalrec;
import criminalRecords.insertCriminalrec;
import criminalRecords.viewCriminalrec;
import cyberCrime.delCyber;
import cyberCrime.insertCyber;
import cyberCrime.viewCyber;
import department.delDept;
import department.insertDept;
import department.viewDept;
import monitors.delMonitors;
import monitors.insertMonitors;
import monitors.viewMonitors;
import users.insertUsers;

public class cyberGUI {
	private JLabel lbl;
	private JFrame f;
	private JMenu mnuusers;
	private JMenu mnuccrime;
	private JMenu mnucomprec;
	private JMenu mnudept;
	private JMenu mnumon;
	private JMenu mnucrec;
	private JMenu mnuactkn;
	private JMenuItem miinusers;
	private JMenuItem midelusers;
	private JMenuItem mivwusers;
	private JMenuItem miinccrime;
	private JMenuItem midelccrime;
	private JMenuItem mivwccrime;
	private JMenuItem miincomprec;
	private JMenuItem midelcomprec;
	private JMenuItem mivwcomprec;
	private JMenuItem miindept;
	private JMenuItem mideldept;
	private JMenuItem mivwdept;
	private JMenuItem miinmon;
	private JMenuItem midelmon;
	private JMenuItem mivwmon;
	private JMenuItem miincrec;
	private JMenuItem midelcrec;
	private JMenuItem mivwcrec;
	private JMenuItem miinactkn;
	private JMenuItem midelactkn;
	private JMenuItem mivwactkn;
	private JMenuBar mnuBar;
	private JPanel pnl;


public cyberGUI() {
	intializeItems();
	AddItemsToFrame();
	
}
public void intializeItems()
{
	f = new JFrame();
	lbl = new JLabel("Cyber Security Data Management");
	mnuBar = new JMenuBar();
	mnuusers = new JMenu("User's Records");
	mnuccrime = new JMenu("Cyber Crime");
	miinusers = new JMenuItem("insert user's");
	midelusers = new JMenuItem("delete user's");
	mivwusers = new JMenuItem("view user's");
	miinccrime = new JMenuItem("insert cyber crime");
	midelccrime = new JMenuItem("delete cyber crime");
	mivwccrime = new JMenuItem("view cyber crime");
	mnucomprec = new JMenu("Complaint's Recieved");
	miincomprec = new JMenuItem("insert complaints recieved");
	midelcomprec = new JMenuItem("delete complaints recieved");
	mivwcomprec = new JMenuItem("view complaints recieved");
	mnudept = new JMenu("Department");
	miindept = new JMenuItem("insert department");
	mideldept = new JMenuItem("delete department");
	mivwdept = new JMenuItem("view department");
	mnumon = new JMenu("Monitor's");
	miinmon = new JMenuItem("insert into monitor's");
	midelmon = new JMenuItem("delete monitor's");
	mivwmon = new JMenuItem("view Monitor's");
	mnucrec = new JMenu("Criminal Record's");
	miincrec = new JMenuItem("insert criminal record");
	midelcrec = new JMenuItem("delete criminal record");
	mivwcrec = new JMenuItem("view criminal records");
	mnuactkn = new JMenu("Action Taken");
	miinactkn = new JMenuItem("insert actiontaken");
	midelactkn = new JMenuItem("delete action taken");
	mivwactkn = new JMenuItem("view action taken");
	pnl = new JPanel(new FlowLayout());
	
}
public void AddItemsToFrame()
{
	mnuusers.add(miinusers);

	mnuusers.add(midelusers);
	mnuusers.add(mivwusers);
	mnuccrime.add(miinccrime);
	mnuccrime.add(midelccrime);
	mnuccrime.add(mivwccrime);
	mnucomprec.add(miincomprec);
	mnucomprec.add(midelcomprec);
	mnucomprec.add(mivwcomprec);
	mnudept.add(miindept);
	mnudept.add(mideldept);
	mnudept.add(mivwdept);
	mnumon.add(miinmon);
	mnumon.add(midelmon);
	mnumon.add(mivwmon);
	mnucrec.add(miincrec);
	mnucrec.add(midelcrec);
	mnucrec.add(mivwcrec);
	mnuactkn.add(miinactkn);
	mnuactkn.add(midelactkn);
	mnuactkn.add(midelactkn);
	mnuactkn.add(mivwactkn);
	mnuBar.add(mnuusers);
	mnuBar.add(mnucomprec);
	mnuBar.add(mnuccrime);
	mnuBar.add(mnumon);
	mnuBar.add(mnudept);
	mnuBar.add(mnuactkn);
	mnuBar.add(mnucrec);
	Font font = new Font("Monaco", Font.BOLD,25);
	Color clr = new Color(200, 100, 150);
 

	lbl.setFont(font);
	lbl.setForeground(Color.RED);
	
	miinusers.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			insertUsers inuser = new insertUsers();
			inuser.insusers();		
			}
	
	});
	midelusers.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			delUsers deluser = new delUsers();
			deluser.delusers();
			// TODO Auto-generated method stub
		}
	});
	mivwusers.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			viewUsers vwuser = new viewUsers();
			vwuser.vwusers();
		}
	});
	miincomprec.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			insertComplaints incomp = new insertComplaints();
			incomp.incompliants();
		}
	});
	midelcomprec.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			delComplaints delComp = new delComplaints();
			delComp.delComp();
		}
	});
	mivwcomprec.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			viewComplaints vwcomp = new viewComplaints();
			vwcomp.vwComp();
			// TODO Auto-generated method stub
		}
	});
	miinccrime.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			insertCyber inscyber = new insertCyber();
			inscyber.insertcyber();
			// TODO Auto-generated method stub
		}
	});
	midelccrime.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			delCyber delcyber = new delCyber();
			delcyber.delcyber();
			// TODO Auto-generated method stub
		}
	});
	mivwccrime.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			viewCyber vwcyber = new viewCyber();
			vwcyber.viewcyber();
		}
	});
	miinmon.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			insertMonitors insmon = new insertMonitors();
			insmon.insmoni();
		}
	});
	midelmon.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			delMonitors delmon = new delMonitors();
			delmon.delmoni();
		}
	});
	mivwmon.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			viewMonitors vwmon = new  viewMonitors();
			vwmon.vwmoni();
		}
	});
	miindept.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			insertDept insdept = new insertDept();
			insdept.insdept();
		}
	});
	mideldept.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			delDept deldept = new delDept();
			deldept.deldept();
		}
	});
	mivwdept.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			viewDept vwDept = new viewDept();
			vwDept.vwdept();
		}
	});
	miinactkn.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			insertAction insacn = new insertAction();
			insacn.insactn();
		}
	});
	midelactkn.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			delAction delactn = new delAction();
			delactn.delacn();
		}
	});
	mivwactkn.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			viewAction vwacn = new viewAction();
			vwacn.vwacn();
		}
	});
	miincrec.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			insertCriminalrec inscrim = new insertCriminalrec();
			inscrim.inscrimrec();
		}
	});
	midelcrec.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			delCriminalrec delcrim = new delCriminalrec();
			delcrim.delcrimrec();
		}
	});
	mivwcrec.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			viewCriminalrec vwcrim = new viewCriminalrec();
			vwcrim.vwcrimrec();
		}
	});
	 f.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent evt) 
			{
				
				int confirmed = JOptionPane.showConfirmDialog(null, "DO YOU WANT TO EXIT?","!!THIS CLOSES ENTERING DATA!!",JOptionPane.YES_NO_OPTION);
		        if(confirmed == JOptionPane.YES_OPTION)
		        {
		        	 System.exit(0);

		        }
				
				  
					
			}   
		 });
	 
	
	f.add(new JLabel(new ImageIcon("C:\\Users\\mahendra\\Desktop\\lang\\java\\dbms/image.jpg")));
		
	//f.setBounds(0,0,0,0);
	
	f.setBackground(clr);
	f.add(pnl);
	f.setJMenuBar(mnuBar);
	f.setTitle("CYBER SECURITY DATA MANAGEMENT");
	f.setLayout(new FlowLayout());
	f.setSize(1400,1400);
	f.setVisible(true);
	
	try {
		UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
	} catch (ClassNotFoundException | InstantiationException | IllegalAccessException
			| UnsupportedLookAndFeelException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	
}
}
