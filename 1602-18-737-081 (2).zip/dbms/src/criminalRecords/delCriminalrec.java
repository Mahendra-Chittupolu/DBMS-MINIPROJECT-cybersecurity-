package criminalRecords;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class delCriminalrec {
	Connection connection;
	Statement statement;
	ResultSet rs;
	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Mahendra","sqlmahi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }

	public void delcrimrec() {
		  try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
			connectToDB();
		JFrame f = new JFrame();
		JPanel pnl = new JPanel();
		JLabel lblpid = new JLabel("PID");
		JLabel lblipadd = new JLabel("IP_ADDRESS");
		JLabel lblname = new JLabel("NAME");
		JTextField jtfpid = new JTextField(15);
		JTextField jtfipadd = new JTextField(15);
		JTextField jtfname = new JTextField(15);
		JPanel pnl1 = new JPanel();
		JButton btn = new JButton("DELETE");
		List lipid = new List(10);
		JTextArea jtadesc = new JTextArea(15,55);
		jtadesc.setEditable(false);
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM criminal_record");
		  while (rs.next()) 
		  {
			lipid.add(rs.getString("PID"));
		  }
		} 
		catch (SQLException e) 
		{ 
			jtadesc.append("\nSQLException: " + e.getMessage() + "\n");
			jtadesc.append("SQLState:     " + e.getSQLState() + "\n");
			jtadesc.append("VendorError:  " + e.getErrorCode() + "\n");
		}
		lipid.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				try {
					rs = statement.executeQuery("SELECT *FROM CRIMINAL_RECORD");
					while (rs.next()) 
					{
						if (rs.getString("PID").equals(lipid.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast())
					{
						jtfipadd.setText(rs.getString("IP_ADDR"));
						jtfpid.setText(rs.getString("PID"));
						jtfname.setText(rs.getString("NAME"));
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					jtadesc.append("\nSQLException: " + e1.getMessage() + "\n");
					jtadesc.append("SQLState:     " + e1.getSQLState() + "\n");
					jtadesc.append("VendorError:  " + e1.getErrorCode() + "\n");
					
					
				}
				
			}
		});
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Statement statement;
				try {
					statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM criminal_record WHERE PID = "
							+ lipid.getSelectedItem());
					jtadesc.append("Deleted "+i+"Rows sucessfully");
					jtfipadd.setText(null);
					jtfpid.setText(null);
					jtfname.setText(null);
					lipid.removeAll();
					try 
					{
					  rs = statement.executeQuery("SELECT * FROM criminal_record");
					  while (rs.next()) 
					  {
						lipid.add(rs.getString("PID"));
					  }
					} 
					catch (SQLException e3) 
					{ 
						jtadesc.append("\nSQLException: " + e3.getMessage() + "\n");
						jtadesc.append("SQLState:     " + e3.getSQLState() + "\n");
						jtadesc.append("VendorError:  " + e3.getErrorCode() + "\n");
					}

				
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					jtadesc.append("\nSQLException: " + e1.getMessage() + "\n");
					jtadesc.append("SQLState:     " + e1.getSQLState() + "\n");
					jtadesc.append("VendorError:  " + e1.getErrorCode() + "\n");
					
				}
				
			}
		});
		pnl1.add(lipid);
		pnl.add(lblpid);
		pnl.add(jtfpid);
		pnl.add(lblname);
		pnl.add(jtfname);
		pnl.add(lblipadd);
		pnl.add(jtfipadd);
		pnl.add(btn);
		pnl.add(jtadesc);
		pnl1.setLayout(new FlowLayout());
		pnl.setLayout(new FlowLayout());
		pnl.setSize(150,150);
		f.getContentPane().setBackground(Color.DARK_GRAY);
		f.add(pnl1);
		f.add(pnl);
		f.setLayout(new FlowLayout());
		f.setSize(1500,600);
		f.setVisible(true);
	}

}
