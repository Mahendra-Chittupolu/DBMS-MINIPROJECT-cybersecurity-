package criminalRecords;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class insertCriminalrec {
	Connection connection;
	Statement statement;
	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Mahendra","sqlmahi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	public void inscrimrec() {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		JFrame f = new JFrame();
		JPanel pnl = new JPanel();
		JLabel lblpid = new JLabel("PID");
		JLabel lblipadd = new JLabel("IP_ADDRESS");
		JLabel lblname = new JLabel("NAME");
		JTextField jtfpid = new JTextField(15);
		JTextField jtfipadd = new JTextField(15);
		JTextField jtfname = new JTextField(15);
		JButton btn = new JButton("SUBMIT");
		JTextArea jta = new JTextArea(25,75);
		jta.setEditable(false);
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					Statement statement = connection.createStatement();
					String query = "INSERT INTO CRIMINAL_RECORD VALUES('"+jtfname.getText()+"','"+jtfipadd.getText()+"','"+jtfpid.getText()+"')";
					int i = statement.executeUpdate(query);
					jta.append("INSERTED"+i+"QUERIES SUCESSFULLY");
					jtfname.setText(null);
					jtfipadd.setText(null);
					jtfpid.setText(null);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					jta.append("\nSQLException: " + e1.getMessage() + "\n");
		     		jta.append("SQLState:     " + e1.getSQLState() + "\n");
		     		jta.append("VendorError:  " + e1.getErrorCode() + "\n");
		     		jtfname.setText(null);
					jtfipadd.setText(null);
					jtfpid.setText(null);
		     		
				}
				
			}
		});
		pnl.add(lblpid);
		pnl.add(jtfpid);
		pnl.add(lblname);
		pnl.add(jtfname);
		pnl.add(lblipadd);
		pnl.add(jtfipadd);
		pnl.add(btn);

		JPanel pnl1 = new JPanel();
		pnl1.add(jta);
		pnl1.setLayout(new FlowLayout());
		pnl.setLayout(new FlowLayout());
		f.getContentPane().setBackground(Color.DARK_GRAY);
		
		f.add(pnl);
		f.add(pnl1);
		f.setSize(1500, 600);
		f.setLayout(new FlowLayout());
	
		f.setVisible(true);
		
	}

}
