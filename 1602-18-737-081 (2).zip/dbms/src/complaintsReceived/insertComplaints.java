package complaintsReceived;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class insertComplaints {
	Connection connection;
	Statement statement;
	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Mahendra","sqlmahi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	

	public void incompliants()
	{	   try 
				{
						Class.forName("oracle.jdbc.driver.OracleDriver");
				} 
		   catch (Exception e) 
			{
			   			System.err.println("Unable to find and load driver");
			   			System.exit(1);
			}
				connectToDB();

		JFrame f = new JFrame();
		JLabel uid = new JLabel("UID");
		JLabel cid = new JLabel("CID");
		JLabel redt = new JLabel("Recieved Date");
		JTextField jtauid = new JTextField(15);
		JTextField jtacid = new JTextField(15);
		JTextField jtaredt = new JTextField(15);
		JButton btnrec = new JButton("SUBMIT");
		JTextArea jtains = new JTextArea(25,25);
		JPanel pnl = new JPanel();
		btnrec.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					Statement statement = connection.createStatement();
					String query = "INSERT INTO COMPLAINTS_RECEIVED VALUES('"+jtauid.getText()+"','"+jtacid.getText()+"','"+jtaredt.getText()+"')";
					int i = statement.executeUpdate(query);
					jtains.append("\n Inserted"+i+"Queries sucessfully\n");
					jtauid.setText(null);
					jtacid.setText(null);
					jtaredt.setText(null);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					jtains.append("\nSQLException: " + e1.getMessage() + "\n");
		     		jtains.append("SQLState:     " + e1.getSQLState() + "\n");
		     		jtains.append("VendorError:  " + e1.getErrorCode() + "\n");
		     		jtauid.setText(null);
					jtacid.setText(null);
					jtaredt.setText(null);
				}
				
				
			}
		});
		pnl.add(uid);
		pnl.add(jtauid);
		pnl.add(cid);
		pnl.add(jtacid);
		pnl.add(redt);
		pnl.add(jtaredt);
		pnl.add(btnrec);
		pnl.add(jtains);
		pnl.setSize(1500,600);
		pnl.setLayout(new FlowLayout());
		f.getContentPane().setBackground(Color.DARK_GRAY);
		f.add(pnl);
		f.setLayout(new FlowLayout());
		f.setVisible(true);
		f.setTitle("Insert Complaint's");
		
		}

}
