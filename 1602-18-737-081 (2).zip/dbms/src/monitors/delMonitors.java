package monitors;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.sql.*;

public class delMonitors {
	Connection connection;
	Statement statement;
	ResultSet rs;
	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Mahendra","sqlmahi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }

	public void delmoni() {
		 try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
			connectToDB();

		JFrame f = new JFrame();
		JTextArea jta = new JTextArea(10,55);
		JLabel lblc = new JLabel("CID");
		JLabel lbleid = new JLabel("EID");
		JLabel lblstat = new JLabel("STATUS");
		JTextField jtfeid = new JTextField(15);
		List lieid = new List(10);
		JTextField jtfstat = new JTextField(15);
		JTextField tfc = new JTextField(15);
		JTextArea jtadesc = new JTextArea(15,50);
		JButton btn = new JButton("DELETE");
		JPanel pnl1 = new JPanel();
		JPanel pnl = new JPanel();
		jta.setEditable(false);
		jtadesc.setEditable(false);
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM MONITORS");
		  while (rs.next()) 
		  {
			lieid.add(rs.getString("EID"));
		  }
		} 
		catch (SQLException e) 
		{ 
			jtadesc.append("\nSQLException: " + e.getMessage() + "\n");
			jtadesc.append("SQLState:     " + e.getSQLState() + "\n");
			jtadesc.append("VendorError:  " + e.getErrorCode() + "\n");
		}
		lieid.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				try {
					rs = statement.executeQuery("SELECT *FROM MONITORS");
					while (rs.next()) 
					{
						if (rs.getString("EID").equals(lieid.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
					jtfeid.setText(rs.getString("EID"));
					jtfstat.setText(rs.getString("STATUS"));
					tfc.setText(rs.getString("CID"));
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					jtadesc.append("\nSQLException: " + e1.getMessage() + "\n");
					jtadesc.append("SQLState:     " + e1.getSQLState() + "\n");
					jtadesc.append("VendorError:  " + e1.getErrorCode() + "\n");
					
				}
				
			}
		});
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				// TODO Auto-generated method stub
				try {
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM MONITORS WHERE EID ="+lieid.getSelectedItem());
					jtadesc.setText(null);
					jtadesc.append("DELETED"+i+"Rows Sucessfully");
					jtfeid.setText(null);
					jtfstat.setText(null);
					tfc.setText(null);
					try {
						rs = statement.executeQuery("SELECT *FROM MONITORS");
						while (rs.next()) 
						{
							if (rs.getString("EID").equals(lieid.getSelectedItem()))
							break;
						}
						if (!rs.isAfterLast()) 
						{
						jtfeid.setText(rs.getString("EID"));
						jtfstat.setText(rs.getString("STATUS"));
						tfc.setText(rs.getString("CID"));
						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						jtadesc.append("\nSQLException: " + e1.getMessage() + "\n");
						jtadesc.append("SQLState:     " + e1.getSQLState() + "\n");
						jtadesc.append("VendorError:  " + e1.getErrorCode() + "\n");
						
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					jtadesc.append("\nSQLException: " + e1.getMessage() + "\n");
					jtadesc.append("SQLState:     " + e1.getSQLState() + "\n");
					jtadesc.append("VendorError:  " + e1.getErrorCode() + "\n");
					
				}
				
			}
		});
		pnl1.add(lieid);
		pnl.add(lblc);
		pnl.add(tfc);
		pnl.add(lbleid);
		pnl.add(jtfeid);
		pnl.add(lblstat);
		pnl.add(jtfstat);
		pnl.add(btn);
		pnl.add(jtadesc);
		
		pnl1.setLayout(new FlowLayout());
		pnl.setLayout(new FlowLayout());
		f.getContentPane().setBackground(Color.DARK_GRAY);
		f.add(pnl1);
		f.add(pnl);
		f.setLayout(new FlowLayout());
		f.setSize(150,150);
		f.setVisible(true);
		
	}
}
