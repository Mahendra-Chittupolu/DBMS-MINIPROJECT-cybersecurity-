package monitors;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class insertMonitors {
	Connection connection;
	Statement statement;
	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Mahendra","sqlmahi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
public void insmoni() {
			try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
			connectToDB();

		JFrame f = new JFrame();
		JPanel pnl = new JPanel();
		JLabel lblc = new JLabel("CID");
		JLabel lble = new JLabel("EID");
		JLabel lbls = new JLabel("Status");
		JTextField tfc = new JTextField(15);
		JTextField tfe = new JTextField(15);
		JTextField tfs = new JTextField(15);
		JTextArea jtadesc = new JTextArea(15,55);
		JButton btnins = new JButton("SUBMIT");
		btnins.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					Statement statement = connection.createStatement();
					String query = "INSERT INTO MONITORS VALUES('"+tfc.getText()+"','"+tfe.getText()+"','"+tfs.getText()+"')";
					int i = statement.executeUpdate(query);
					jtadesc.append("\nInserted"+i+"Queries Sucessfully\n");
					tfc.setText(null);
					tfe.setText(null);
					tfs.setText(null);
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					jtadesc.append("\nSQLException: " + e1.getMessage() + "\n");
		     		jtadesc.append("SQLState:     " + e1.getSQLState() + "\n");
		     		jtadesc.append("VendorError:  " + e1.getErrorCode() + "\n");
					e1.printStackTrace();
					tfc.setText(null);
					tfe.setText(null);
					tfs.setText(null);
				}
				
				
			}
		});
		pnl.add(lblc);
		pnl.add(tfc);
		pnl.add(lble);
		pnl.add(tfe);
		pnl.add(lbls);
		pnl.add(tfs);
		pnl.add(btnins);
		pnl.add(jtadesc);
		pnl.setLayout(new FlowLayout());
		pnl.setSize(1000,1000);
		f.getContentPane().setBackground(Color.GRAY);
		f.add(pnl);
		f.setLayout(new FlowLayout());
		f.setVisible(true);
		f.setSize(250,300);
	}

}
