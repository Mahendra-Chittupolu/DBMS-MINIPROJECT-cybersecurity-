package users;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class viewUsers {
	Connection connection;
	Statement statement;
	ResultSet rs;
	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Mahendra","sqlmahi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	public void vwusers() {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		JFrame f = new JFrame();
		JLabel lname;
		JLabel lphno;
		JLabel lusid;
		JLabel lage;
		JLabel lhno;
		JLabel lstreet;
		JLabel lmandal;
		JLabel ldistrict;
		JTextField tfname;
		JTextField tfphno;
		JTextField tfusid;
		JTextField tfage;
		JTextField tfhno;
		JTextField tfstreet;
		JTextField tfmandal;
		JTextField tfdistrict;
		JTextArea jtadesc;
		JButton btnup;
		List liusid;
	
		
		lname = new JLabel("Name");
		lphno = new JLabel("Ph.no");
		lusid = new JLabel("User id");
		lage = new JLabel("Age");
		lhno = new JLabel("H:no");
		lstreet = new JLabel("Street");
		lmandal = new JLabel("Mandal");
		ldistrict = new JLabel("District");
		tfname = new JTextField(15);
		tfphno = new JTextField(15);
		tfusid = new JTextField(15);
		tfage = new JTextField(15);
		tfhno = new JTextField(15);
		tfstreet = new JTextField(15);
		tfmandal = new JTextField(15);
		tfdistrict = new JTextField(15);
		jtadesc = new JTextArea(10,50);
		liusid = new List(10);
		btnup = new JButton("MODIFY");
	    JPanel pnlname = new JPanel();
	    JPanel pnlphno = new JPanel();
	    JPanel pnlusid = new JPanel();
	    JPanel pnlage = new JPanel();
	    JPanel pnlhno = new JPanel();
	    JPanel pnlstreet = new JPanel();
	    JPanel pnlmandal = new JPanel();
	    JPanel pnldistrict = new JPanel();
	    JPanel pnl = new JPanel();
	    JPanel pnl1 = new JPanel();
	    JPanel pnl2 = new JPanel();
	    jtadesc.setEditable(false);
	    try 
		{
		  rs = statement.executeQuery("SELECT * FROM USERS_RECORD");
		  while (rs.next()) 
		  {
			liusid.add(rs.getString("USID"));
		  }
		} 
		catch (SQLException e) 
		{ 
			jtadesc.append("\nSQLException: " + e.getMessage() + "\n");
			jtadesc.append("SQLState:     " + e.getSQLState() + "\n");
			jtadesc.append("VendorError:  " + e.getErrorCode() + "\n");
		}
	    liusid.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				try {
					rs = statement.executeQuery("SELECT *FROM USERS_RECORD WHERE USID = "+liusid.getSelectedItem());
					rs.next();
					tfusid.setText(rs.getString("USID"));
					tfname.setText(rs.getString("NAME"));
					tfage.setText(rs.getString("AGE"));
					tfdistrict.setText(rs.getString("DISTRICT"));
					tfhno.setText(rs.getString("HNO"));
					tfmandal.setText(rs.getString("MANDAL"));
					tfphno.setText(rs.getString("PHNO"));
					tfstreet.setText(rs.getString("STREET"));
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					jtadesc.append("\nSQLException: " + e1.getMessage() + "\n");
					jtadesc.append("SQLState:     " + e1.getSQLState() + "\n");
					jtadesc.append("VendorError:  " + e1.getErrorCode() + "\n");
				}
				
			}
		});
	    btnup.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("update users_record SET name ='"+tfname.getText()+"',phno ="+tfphno.getText()+",usid = '"+tfusid.getText()+
							"',age ="+tfage.getText()+", hno ='"+tfhno.getText()+"',street ='"+tfstreet.getText()+"',mandal ='"+tfmandal.getText()+
							"' ,district ='"+tfdistrict.getText()+"' where usid = '"+liusid.getSelectedItem()+"'");
					jtadesc.setText(null);
					jtadesc.append("Updated"+i+"rows sucessfully");
					liusid.removeAll();
					tfname.setText(null);
					tfage.setText(null);
					tfdistrict.setText(null);
					tfhno.setText(null);
					tfmandal.setText(null);
					tfphno.setText(null);
					tfstreet.setText(null);
					tfusid.setText(null);
					 try 
						{
						  rs = statement.executeQuery("SELECT * FROM USERS_RECORD");
						  while (rs.next()) 
						  {
							liusid.add(rs.getString("USID"));
						  }
						} 
						catch (SQLException e3) 
						{ 
							jtadesc.append("\nSQLException: " + e3.getMessage() + "\n");
							jtadesc.append("SQLState:     " + e3.getSQLState() + "\n");
							jtadesc.append("VendorError:  " + e3.getErrorCode() + "\n");
						}
				
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					jtadesc.append("ENTER PHNO AND AGE IN NUMBER FORMAT ONLY");
					jtadesc.append("\nSQLException: " + e1.getMessage() + "\n");
					jtadesc.append("SQLState:     " + e1.getSQLState() + "\n");
					jtadesc.append("VendorError:  " + e1.getErrorCode() + "\n");

					
				}
			}
		});
	    pnl1.add(liusid);
	    pnlusid.add(lusid);
	    pnlusid.add(tfusid);
	    pnlusid.setLayout(new FlowLayout());
	    pnlname.add(lname);
	    pnlname.add(tfname);
	    pnlname.setLayout(new FlowLayout());
	    pnlage.add(lage);
	    pnlage.add(tfage);
	    pnlage.setLayout(new FlowLayout());
	    pnlhno.add(lhno);
	    pnlhno.add(tfhno);
	    pnlhno.setLayout(new FlowLayout());
	    pnlstreet.add(lstreet);
	    pnlstreet.add(tfstreet);
	    pnlstreet.setLayout(new FlowLayout());
	    pnlmandal.add(lmandal);
	    pnlmandal.add(tfmandal);
	    pnlmandal.setLayout(new FlowLayout());
	    pnldistrict.add(ldistrict);
	    pnldistrict.add(tfdistrict);
	    pnldistrict.setLayout(new FlowLayout());
	    
	    pnlphno.add(lphno);
	    pnlphno.add(tfphno);
	    pnlphno.setLayout(new FlowLayout());
	    pnl.add(pnlusid);
	    pnl.add(pnlname);
	    pnl.add(pnlphno);
	    pnl.add(pnlage);
	    pnl.add(pnlhno);
	    pnl.add(pnlstreet);
	    pnl.add(pnlmandal);
	    pnl.add(pnldistrict);
	    pnl2.add(btnup);
	    pnl2.add(jtadesc);
	    pnl2.setLayout(new FlowLayout());
	    pnl1.setLayout(new FlowLayout());
	    pnl.setLayout(new FlowLayout());
	    f.getContentPane().setBackground(Color.DARK_GRAY);
	    f.add(pnl1);
	    f.add(pnl);
	    f.add(pnl2);
	    
	   f.setSize(1500,600);
	    f.setLayout(new FlowLayout());
	    f.setVisible(true);

	}

}
