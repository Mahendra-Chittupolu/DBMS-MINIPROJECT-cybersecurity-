package users;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class insertUsers {
	Connection connection;
	Statement statement;
	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Mahendra","sqlmahi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	
	public void insusers() {
		    try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
			connectToDB();
		JFrame f = new JFrame();
		JLabel lname;
		JLabel lphno;
		JLabel lusid;
		JLabel lage;
		JLabel lhno;
		JLabel lstreet;
		JLabel lmandal;
		JLabel ldistrict;
		JTextField tfname;
		JTextField tfphno;
		JTextField tfusid;
		JTextField tfage;
		JTextField tfhno;
		JTextField tfstreet;
		JTextField tfmandal;
		JTextField tfdistrict;
		JTextArea tfdesc;
		JButton btnins;
		
		
		lname = new JLabel("Name");
		lphno = new JLabel("Ph.no");
		lusid = new JLabel("User id");
		lage = new JLabel("Age");
		lhno = new JLabel("H:no");
		lstreet = new JLabel("Street");
		lmandal = new JLabel("Mandal");
		ldistrict = new JLabel("District");
		tfname = new JTextField(15);
		tfphno = new JTextField(15);
		tfusid = new JTextField(15);
		tfage = new JTextField(15);
		tfhno = new JTextField(15);
		tfstreet = new JTextField(15);
		tfmandal = new JTextField(15);
		tfdistrict = new JTextField(15);
		tfdesc = new JTextArea(10,55);
		btnins = new JButton("SUBMIT");
		JPanel pnl = new JPanel();
	    JPanel pnl1 = new JPanel();
	    JPanel pnl2 = new JPanel();
	    
	   
         btnins.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try 
				{
				  Statement statement = connection.createStatement();
				  //String query = "INSERT INTO sailors (userid,NAME,AGE,hno,street,mandal,dist) VALUES (2,'Divya',7,20)";				  
				  String query= "INSERT INTO users_record VALUES('"+tfname.getText()+"',"+ tfphno.getText() +",'"+tfusid.getText()+"','"+tfage.getText()+"','"+tfhno.getText() +"','"+tfstreet.getText()+"','"+tfmandal.getText()+"','"+tfdistrict.getText()+"')";
				  int i = statement.executeUpdate(query);
				  tfdesc.setText(null);
				  tfdesc.append("\nInserted " + i + " rows successfully");
				  tfname.setText(null);
				  tfphno.setText(null);
				  tfusid.setText(null);
				  tfage.setText(null);
				  tfhno.setText(null);
				  tfstreet.setText(null);
				  tfdistrict.setText(null);
				  tfmandal.setText(null);
				  
				  
				} 
				catch (SQLException insertException) 
				{		
						
						tfdesc.append("\nENTER phno and age in number format ONLY!!");
			     		tfdesc.append("\nSQLException: " + insertException.getMessage() + "\n");
			     		tfdesc.append("SQLState:     " + insertException.getSQLState() + "\n");
			     		tfdesc.append("VendorError:  " + insertException.getErrorCode() + "\n");
			     		
			     		tfname.setText(null);
						  tfphno.setText(null);
						  tfusid.setText(null);
						  tfage.setText(null);
						  tfhno.setText(null);
						  tfstreet.setText(null);
						  tfdistrict.setText(null);
						  tfmandal.setText(null);
						  
			     	
				}
			}
		});

     
	    
	   pnl1.add(lusid);
	   pnl1.add(tfusid);
	   pnl1.add(lname);
	   pnl1.add(tfname);
	   pnl1.add(lphno);
	   pnl1.add(tfphno);
	   pnl1.add(lage);
	   pnl1.add(tfage);
	   pnl1.add(lhno);
	   pnl1.add(tfhno);
	   pnl1.add(lstreet);
	   pnl1.add(tfstreet);
	   pnl1.add(lmandal);
	   pnl1.add(tfmandal);
	   pnl1.add(ldistrict);
	   pnl1.add(tfdistrict);
	   pnl2.add(tfdesc);
	   pnl.add(btnins);
	   pnl1.setLayout(new FlowLayout());
	   pnl2.setLayout(new FlowLayout());
	    
	    f.getContentPane().setBackground(Color.DARK_GRAY);
	  
	    f.add(pnl1);
	    f.add(pnl);
	    f.add(pnl2);
	    
	    f.setLayout(new FlowLayout());
	   
	    f.setVisible(true);
	    f.setSize(1500,600);
	    f.setTitle("Insert User's");
	    
	}
}
