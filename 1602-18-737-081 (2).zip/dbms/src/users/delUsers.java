package users;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import java.awt.*;

import java.sql.*;

public class delUsers {
	Connection connection;
	Statement statement;
	ResultSet rs;
	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Mahendra","sqlmahi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	public void delusers() {
		  try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
			connectToDB();
		JFrame f = new JFrame();
		JLabel lname = new JLabel("Name");
		JLabel lphno = new JLabel("PH.NO");
		JLabel luserid = new JLabel("User I'D");
		JLabel lage = new JLabel("AGE");
		JLabel lhno = new JLabel("H.no");
		JLabel lstreet = new JLabel("Street");
		JLabel lmandal = new JLabel("Mandal");
		JLabel ldist = new JLabel("District");
		JTextField tfuserid = new JTextField(15);
		JTextField tfname = new JTextField(15);
		JTextField tfphno = new JTextField(15);
		JTextField tfage = new JTextField(15);
		JTextField tfhno = new JTextField(15);
		JTextField tfstreet = new JTextField(15);
		JTextField tfmandal = new JTextField(15);
		JTextField tfdist = new JTextField(15);
		 List uidlist = new List(10);
		JButton btndel = new JButton("DELETE");
		JTextArea jtadesc = new JTextArea(15,55);
		JPanel pnl1 = new JPanel();
		JPanel pnl2 = new JPanel();
		jtadesc.setEditable(false);
			try 
			{
			  rs = statement.executeQuery("SELECT * FROM users_record");
			  while (rs.next()) 
			  {
				uidlist.add(rs.getString("USID"));
			  }
			} 
			catch (SQLException e) 
			{ 
				jtadesc.append("\nSQLException: " + e.getMessage() + "\n");
				jtadesc.append("SQLState:     " + e.getSQLState() + "\n");
				jtadesc.append("VendorError:  " + e.getErrorCode() + "\n");
			}
		uidlist.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				try {
					rs =statement.executeQuery("select *from users_record");
					while (rs.next()) 
					{
						if (rs.getString("USID").equals(uidlist.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						tfuserid.setText(rs.getString("USID"));
						tfname.setText(rs.getString("NAME"));
						tfphno.setText(rs.getString("PHNO"));
						tfage.setText(rs.getString("AGE"));
						tfhno.setText(rs.getString("HNO"));
						tfstreet.setText(rs.getString("STREET"));
						tfmandal.setText(rs.getString("MANDAL"));
						tfdist.setText(rs.getString("DISTRICT"));
						
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					jtadesc.append("\nSQLException: " + e1.getMessage() + "\n");
					jtadesc.append("SQLState:     " + e1.getSQLState() + "\n");
					jtadesc.append("VendorError:  " + e1.getErrorCode() + "\n");
					
				}
				
			}
		});
		btndel.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM users_record WHERE USID = "
							+ uidlist.getSelectedItem());
					jtadesc.append("\nDeleted"+i+"Rows Sucessfully");
					tfuserid.setText(null);
					tfstreet.setText(null);
					tfphno.setText(null);
					tfname.setText(null);
					tfmandal.setText(null);
					tfhno.setText(null);
					tfdist.setText(null);
					tfage.setText(null);
					uidlist.removeAll();
					try 
					{
					  rs = statement.executeQuery("SELECT * FROM users_record");
					  while (rs.next()) 
					  {
						uidlist.add(rs.getString("USID"));
					  }
					} 
					catch (SQLException e3) 
					{ 
						jtadesc.append("\nSQLException: " + e3.getMessage() + "\n");
						jtadesc.append("SQLState:     " + e3.getSQLState() + "\n");
						jtadesc.append("VendorError:  " + e3.getErrorCode() + "\n");
					}

					
				} catch (SQLException e5) {
					jtadesc.append("\nSQLException: " + e5.getMessage() + "\n");
					jtadesc.append("SQLState:     " + e5.getSQLState() + "\n");
					jtadesc.append("VendorError:  " + e5.getErrorCode() + "\n");
				}
			}
		});
		
		pnl2.add(uidlist);
		pnl1.add(lname);
		pnl1.add(tfname);
		pnl1.add(lphno);
		pnl1.add(tfphno);
		pnl1.add(luserid);
		pnl1.add(tfuserid);
		pnl1.add(lage);
		pnl1.add(tfage);
		pnl1.add(lhno);
		pnl1.add(tfhno);
		pnl1.add(lstreet);
		pnl1.add(tfstreet);
		pnl1.add(lmandal);
		pnl1.add(tfmandal);
		pnl1.add(ldist);
		pnl1.add(tfdist);
		JPanel pnl3 = new JPanel();
		pnl3.add(jtadesc);
		JPanel pnl = new JPanel();
		pnl.add(btndel);
		pnl1.setLayout(new FlowLayout());
		pnl.setLayout(new FlowLayout());
		pnl3.setLayout(new FlowLayout());
		f.getContentPane().setBackground(Color.DARK_GRAY);
		f.setSize(1500, 600);
		f.add(pnl2);
		f.add(pnl1);
		f.add(pnl);
		f.add(pnl3);
	
		f.setLayout(new FlowLayout());
		f.setVisible(true);
		
		
	}

}
