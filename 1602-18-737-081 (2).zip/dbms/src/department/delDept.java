package department;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class delDept {
	Connection connection;
	Statement statement;
	ResultSet rs;
	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Mahendra","sqlmahi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	public void deldept() {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	
	JTextArea jtadesc = new JTextArea(15,50);
	JFrame f = new JFrame();
	JLabel lbleid = new JLabel("EID");
	JLabel lblename = new JLabel("EName");
	JLabel lbldesgn = new JLabel("Designation");
	JLabel lblbrnch = new JLabel("Branch");
	JTextField jtfeid = new JTextField(15);
	JTextField jtfename = new JTextField(15);
	JTextField jtfdesgn = new JTextField(15);
	JTextField jtfbrnch = new JTextField(15);
	List lieid = new List(10);
	JButton btn = new JButton("DELETE");
	JPanel pnl = new JPanel();
	JPanel pnl1 = new JPanel();
	jtadesc.setEditable(false);
	try {
		rs = statement.executeQuery("SELECT * FROM DEPARTMENT");
		
		while (rs.next()) 
		  {
			lieid.add(rs.getString("EID"));
		  }
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		jtadesc.append("\nSQLException: " + e.getMessage() + "\n");
		jtadesc.append("SQLState:     " + e.getSQLState() + "\n");
		jtadesc.append("VendorError:  " + e.getErrorCode() + "\n");
		
	}
	lieid.addItemListener(new ItemListener() {
		
		@Override
		public void itemStateChanged(ItemEvent e) {
			// TODO Auto-generated method stub
			try {
				rs = statement.executeQuery("select *from department");
				while (rs.next()) 
				{
					if (rs.getString("EID").equals(lieid.getSelectedItem()))
					break;
				}
				if (!rs.isAfterLast()) 
				{
				jtfbrnch.setText(rs.getString("BRANCH"));
				jtfdesgn.setText(rs.getString("DESIGNATION"));
				jtfeid.setText(rs.getString("EID"));
				jtfename.setText(rs.getString("ENAME"));
				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				jtadesc.append("\nSQLException: " + e1.getMessage() + "\n");
				jtadesc.append("SQLState:     " + e1.getSQLState() + "\n");
				jtadesc.append("VendorError:  " + e1.getErrorCode() + "\n");
			}
			
		}
	});
	btn.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			try {
				Statement statement = connection.createStatement();
				System.out.println("hi");
				System.out.println(lieid.getSelectedItem());
				int i = statement.executeUpdate("DELETE FROM DEPARTMENT WHERE EID ="+lieid.getSelectedItem());
				System.out.println("hello");
				jtadesc.setText(null);
				jtadesc.setText("Deleted"+i+"Rows sucessfully");
				jtfbrnch.setText(null);
				jtfdesgn.setText(null);
				jtfeid.setText(null);
				jtfename.setText(null);
				lieid.removeAll();
				try 
				{
				  rs = statement.executeQuery("SELECT * FROM department");
				  while (rs.next()) 
				  {
					lieid.add(rs.getString("EID"));
				  }
				} 									//loading table
				catch (SQLException e3) 
				{ 
					jtadesc.append("\nSQLException: " + e3.getMessage() + "\n");
					jtadesc.append("SQLState:     " + e3.getSQLState() + "\n");
					jtadesc.append("VendorError:  " + e3.getErrorCode() + "\n");

			   }
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				jtadesc.append("\nSQLException: " + e1.getMessage() + "\n");
				jtadesc.append("SQLState:     " + e1.getSQLState() + "\n");
				jtadesc.append("VendorError:  " + e1.getErrorCode() + "\n");
			
			}
			
		}
	});
	pnl1.add(lieid);
	pnl.add(lbleid);
	pnl.add(jtfeid);
	pnl.add(lblename);
	pnl.add(jtfename);
	pnl.add(lbldesgn);
	pnl.add(jtfdesgn);
	pnl.add(lblbrnch);
	pnl.add(jtfbrnch);
	pnl.add(btn);
	pnl.add(jtadesc);
	pnl.setLayout(new FlowLayout());
	pnl1.setLayout(new FlowLayout());
	f.getContentPane().setBackground(Color.DARK_GRAY);
	f.add(pnl1);
	f.add(pnl);
	f.setSize(1500,600);
	f.setLayout(new FlowLayout());
    f.setVisible(true);
	
	}
}
