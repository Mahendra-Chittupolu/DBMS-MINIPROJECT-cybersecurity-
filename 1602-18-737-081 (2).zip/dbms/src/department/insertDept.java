package department;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class insertDept {
	Connection connection;
	Statement statement;
	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Mahendra","sqlmahi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }

	public void insdept() {
			try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
			connectToDB();
		JFrame f = new JFrame();
		JLabel lbleid = new JLabel("EID");
		JLabel lblename = new JLabel("EName");
		JLabel lbldesgn = new JLabel("Designation");
		JLabel lblbrnch = new JLabel("Branch");
		JTextField jtfeid = new JTextField(15);
		JTextField jtfename = new JTextField(15);
		JTextField jtfdesgn = new JTextField(15);
		JTextField jtfbrnch = new JTextField(15);
		JTextArea jta = new JTextArea(15,50);
		JButton btn = new JButton("SUBMIT");
		JPanel pnl = new JPanel();
		jta.setEditable(false);
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					Statement statement = connection.createStatement();
					String query = "INSERT INTO DEPARTMENT VALUES('"+jtfeid.getText()+"','"+jtfename.getText()+"','"+jtfdesgn.getText()+"','"+jtfbrnch.getText()+"')";
					int i = statement.executeUpdate(query);
					jta.append("\nInserted"+i+"Queries sucessfully\n");
					jtfeid.setText(null);
					jtfename.setText(null);
					jtfdesgn.setText(null);
					jtfbrnch.setText(null);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					jta.append("\nSQLException: " + e1.getMessage() + "\n");
		     		jta.append("SQLState:     " + e1.getSQLState() + "\n");
		     		jta.append("VendorError:  " + e1.getErrorCode() + "\n");
		     		jtfeid.setText(null);
					jtfename.setText(null);
					jtfdesgn.setText(null);
					jtfbrnch.setText(null);
		     		
					
				}
				
			}
		});
		
		pnl.add(lbleid);
		pnl.add(jtfeid);
		pnl.add(lblename);
		pnl.add(jtfename);
		pnl.add(lbldesgn);
		pnl.add(jtfdesgn);
		pnl.add(lblbrnch);
		pnl.add(jtfbrnch);
		pnl.add(jta);
		pnl.add(btn);
		pnl.add(jta);
		pnl.setLayout(new FlowLayout());
		f.getContentPane().setBackground(Color.DARK_GRAY);
		f.setSize(1500,600);
		f.add(pnl);
		f.setLayout(new FlowLayout());
	
		f.setVisible(true);
		
		
		
	}

}
