package cyberCrime;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;



public class viewCyber {
	Connection connection;
	Statement statement;
	ResultSet rs;
	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Mahendra","sqlmahi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	public void viewcyber()
	{	try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		JFrame f = new JFrame();
		List licid = new List(10);
		JLabel lcid = new JLabel("CID");
		JTextField jtfcid = new JTextField(15);
		JLabel jllocation = new JLabel("location");
		JTextField jtfloc = new JTextField(15);
		JLabel jlcat = new JLabel("Category");
		JTextField jtfcat = new JTextField(15);
		JButton btn = new JButton("MODIFY");
		JTextArea jtadesc = new JTextArea(10,55);
		jtadesc.setEditable(false);
		JPanel pnl = new JPanel();
		JPanel pnl1 = new JPanel();
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM CYBER_CRIME");
		  while (rs.next()) 
		  {
			licid.add(rs.getString("CID"));
		  }
		} 
		catch (SQLException e) 
		{ 
			jtadesc.append("\nSQLException: " + e.getMessage() + "\n");
			jtadesc.append("SQLState:     " + e.getSQLState() + "\n");
			jtadesc.append("VendorError:  " + e.getErrorCode() + "\n");
		}
		licid.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				try {
					rs = statement.executeQuery("SELECT *FROM CYBER_CRIME WHERE CID ="+licid.getSelectedItem());
					rs.next();
					jtfcat.setText(rs.getString("CATEGORY"));
					jtfcid.setText(rs.getString("CID"));
					jtfloc.setText(rs.getString("LOCATION"));
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					jtadesc.append("\nSQLException: " + e1.getMessage() + "\n");
					jtadesc.append("SQLState:     " + e1.getSQLState() + "\n");
					jtadesc.append("VendorError:  " + e1.getErrorCode() + "\n");
				}
				
			}
		});
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("update cyber_crime set cid ='"+jtfcid.getText()+"',location ='"+jtfloc.getText()+"',category ='"+jtfcat.getText()+"'"
							+ "where cid ='"+licid.getSelectedItem()+"'");
					jtadesc.setText(null);
					jtadesc.append("Updated"+i+"rows sucessfully");
					licid.removeAll();
					jtfcat.setText(null);
					jtfloc.setText(null);
					jtfcid.setText(null);
					try 
					{
					  rs = statement.executeQuery("SELECT * FROM cyber_crime");
					  while (rs.next()) 
					  {
						licid.add(rs.getString("CID"));
					  }
					} 
					catch (SQLException e3) 
					{ 
						jtadesc.append("\nSQLException: " + e3.getMessage() + "\n");
						jtadesc.append("SQLState:     " + e3.getSQLState() + "\n");
						jtadesc.append("VendorError:  " + e3.getErrorCode() + "\n");
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					jtadesc.append("\nSQLException: " + e1.getMessage() + "\n");
					jtadesc.append("SQLState:     " + e1.getSQLState() + "\n");
					jtadesc.append("VendorError:  " + e1.getErrorCode() + "\n");
					
				}
				
				
			}
		});
		pnl1.add(licid);
		pnl.add(lcid);
		pnl.add(jtfcid);
		pnl.add(jllocation);
		pnl.add(jtfloc);
		pnl.add(jlcat);
		pnl.add(jtfcat);
		pnl.add(btn);
		pnl.add(jtadesc);
		pnl1.setLayout(new FlowLayout());
		pnl.setLayout(new FlowLayout());
		f.getContentPane().setBackground(Color.DARK_GRAY);
		f.add(pnl1);
		f.add(pnl);
		f.setLayout(new FlowLayout());
		f.setSize(1500,600);
		f.setVisible(true);
	}
}
