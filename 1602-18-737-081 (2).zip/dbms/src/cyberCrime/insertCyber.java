package cyberCrime;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class insertCyber {
	Connection connection;
	Statement statement;
	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Mahendra","sqlmahi");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }


	public void insertcyber()
	{   try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		JFrame f = new JFrame();
		JLabel lcid = new JLabel("CID");
		JTextField jtfcid = new JTextField(15);
		JLabel llocation = new JLabel("Location");
		JTextField jtflocation = new JTextField(15);
		JLabel lcat = new JLabel("Category");
		JTextField jtfcat = new JTextField(15);
		JButton btn = new JButton("SUBMIT");
		JTextArea jtadet = new JTextArea(15,55);
		JPanel pnl = new JPanel();
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					Statement statement = connection.createStatement();
					String query = "INSERT INTO CYBER_CRIME VALUES('"+jtfcid.getText()+"','"+jtflocation.getText()+"','"+jtfcat.getText()+"')";
					int i = statement.executeUpdate(query);
					jtadet.append("\nInserted "+i+"Queries Sucessfully");
					jtfcid.setText(null);
					jtflocation.setText(null);
					jtfcat.setText(null);
				} catch (SQLException e1) {
					
					// TODO Auto-generated catch block

		     		jtadet.append("\nSQLException: " + e1.getMessage() + "\n");
		     		jtadet.append("SQLState:     " + e1.getSQLState() + "\n");
		     		jtadet.append("VendorError:  " + e1.getErrorCode() + "\n");
		     		jtfcid.setText(null);
					jtflocation.setText(null);
					jtfcat.setText(null);
				}
				
				
			}
		});
		pnl.add(lcid);
		pnl.add(jtfcid);
		pnl.add(llocation);
		pnl.add(jtflocation);
		pnl.add(lcat);
		pnl.add(jtfcat);
		pnl.add(btn);
		pnl.add(jtadet);
		pnl.setSize(250,250);
		pnl.setLayout(new FlowLayout());
		f.getContentPane().setBackground(Color.DARK_GRAY);
		f.add(pnl);
		f.setLayout(new FlowLayout());
		f.setSize(1500,600);
		f.setVisible(true);
	
		
		
	}
}
